package com.comparefacespucmm.myapplication.Model

class Master{

    var id : String = ""
    var date : String = ""
    var name : String = ""

}