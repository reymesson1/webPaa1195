package com.comparefacespucmm.myapplication

import android.os.Environment
import java.io.File

class RestAPI{

    var emptyArray = arrayOfNulls<String>(100)

    var count = 0

    fun getData() : Array<String?>{

        return emptyArray
    }

    fun setData(name:String){




//        emptyArray[0] = "Hello"
//        emptyArray[1] = "World"

        emptyArray.set(count,name)

        count++

    }

}