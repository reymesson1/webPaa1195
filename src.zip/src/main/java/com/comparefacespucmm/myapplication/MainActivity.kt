package com.comparefacespucmm.myapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.layout_item.view.*
import org.jetbrains.anko.activityUiThread
import org.jetbrains.anko.doAsync
import java.io.File

class MainActivity : AppCompatActivity() {

    var rest = RestAPI()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val storageDir: File = getExternalFilesDir(Environment.DIRECTORY_PICTURES)

        imageReaderNew(storageDir)

        doAsync {

            activityUiThread {

                Thread.sleep(2000)

                getRender()

            }
        }
    }

    fun imageReaderNew(root: File) {
        val fileList: ArrayList<File> = ArrayList()
        val listAllFiles = root.listFiles()

        if (listAllFiles != null && listAllFiles.size > 0) {
            for (currentFile in listAllFiles) {
                if (currentFile.name.endsWith(".jpeg")) {
                    // File absolute path
                    Log.e("downloadFilePath", currentFile.getAbsolutePath())
                    // File Name
                    Log.e("downloadFileName", currentFile.getName())
                    rest.setData(currentFile.name)
                    fileList.add(currentFile.absoluteFile)
                }
            }
            Log.w("fileList", "" + fileList.size)
        }
    }

    fun getRender(){

        var masterService = rest.getData()

        masterService.forEach {at->

            var item = layoutInflater.inflate(R.layout.layout_item, null)

            item.nameTXT.setText(at)

            scContent.addView(item)

        }

    }

}